#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Empleado.h"


int parser_parseEmpleados(char* path, ArrayList* listaEmpleados)
{
    int retorno = -1;
    char bId[4096];
    char bName[4096];
    char bHorasTrabajadas[4096];
    FILE* pFile;
    Empleado* auxiliarEmpleado;

    if(path != NULL)
    {
        pFile = fopen(path, "r");
        retorno = 0;
        fscanf(pFile,"%[^,],%[^,],%[^\n]\n",bId,bName,bHorasTrabajadas);
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^\n]\n",bId,bName,bHorasTrabajadas);
            auxiliarEmpleado = Empleado_newParametros(bId,bName,bHorasTrabajadas);
            al_add(listaEmpleados,auxiliarEmpleado);

        }
    }

    return retorno;
}
